### General Info
***
This is a challenge to create a landing page according to an established design

### Technologies
***
A list of technologies used within the project:
* HTML5
* CSS
* Javascript
* [Bootstrap](https://getbootstrap.com/docs/5.0/getting-started/introduction/): Version 5